## Packages
framer-motion | Smooth scroll reveals and entry animations
react-intersection-observer | Trigger animations when elements enter viewport

## Notes
Static logo available at @assets/4_1771722650806.png
Primary colors: Dark Blue (#132757) and Red/Orange (#F83429)
WhatsApp link: https://wa.me/5511912548292
API endpoint: POST /api/leads for the contact form
